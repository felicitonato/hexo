
module.exports = {'options': {'lineNumbers': false},
                  'editor': {'lineNumbers':false}}
