module.exports = {"categories":{"247bgen6wg4wt21y":"The Best Category","sabslzxuqj0nryqy":"Sub Cat"},"tags":{"khs0fyclcklebuuh":"One tag","mgmzanv3udntfcq5":"another tag"}}
